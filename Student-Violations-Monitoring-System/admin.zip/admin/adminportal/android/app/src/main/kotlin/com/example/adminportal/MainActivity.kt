package com.example.adminportal

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
