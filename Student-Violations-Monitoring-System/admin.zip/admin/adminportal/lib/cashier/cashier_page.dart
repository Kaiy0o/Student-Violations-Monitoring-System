import 'package:flutter/material.dart';

class CashierPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Cashier Dashboard')),
      body: Center(
        child: Text('Welcome to the Cashier Dashboard'),
      ),
    );
  }
}
