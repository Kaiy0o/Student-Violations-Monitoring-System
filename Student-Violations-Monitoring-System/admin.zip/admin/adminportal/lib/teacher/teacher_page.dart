import 'package:flutter/material.dart';

class TeacherPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Teacher Dashboard')),
      body: Center(
        child: Text('Welcome to the Teacher Dashboard'),
      ),
    );
  }
}
